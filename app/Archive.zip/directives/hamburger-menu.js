angular.module('cbrAPP')

	.directive('hamburgerMenu', function(){
		return {
			retrict: 'E', 
			templateUrl: 'partials/hamburger-menu.html'
		}
	})